active = 0;
letter = "W"; //This is the letter being used.