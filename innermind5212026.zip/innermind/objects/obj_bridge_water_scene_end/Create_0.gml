if global.story >= 5
{
	instance_destroy();
}
spoken = 0;
active = 0;
enabled = 0;
talkedwith = 0;

thespecial = 1; //Triggers special events in the script talking
maxspoken = 1;
face = obj_textbox_image_parent;
fulltext = "\"Cookie still thinks " + global.playername + " shoulda taken the bridge.\"";
//fulltext1 = "* ...";
//fulltext2 = "Cookie stands by Cookie's opinion";