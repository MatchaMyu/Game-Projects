if enabled != 2
{
	if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
	{

	if distance_to_object(obj_player) < 32 && talkedwith != 2
		{
		 scr_talking(id);
		}
	}
}

if enabled = 3 && !instance_exists(obj_textbox_box)
{
instance_create_depth(x,y,0,obj_forestbridge_scene_cleanup);
}