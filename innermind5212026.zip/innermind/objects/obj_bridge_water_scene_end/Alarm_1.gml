spoken = 0;
maxspoken = 2;
fulltext = "...";
fulltext1 = "\"Cookie stands by Cookie's opinion.\"";

if enabled != 3
{
global.scene_pause = false;
enabled = 3;
scr_talking(id);
}