if enabled = 0
{
	if (place_meeting(x, y, obj_player))
	{
	 global.scene_pause = true;
	 scr_talking(id);
	 enabled = 1;
	}
}