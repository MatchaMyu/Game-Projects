global.playerx = 96;
global.playery = 1264;
room_goto(rm_forest9);