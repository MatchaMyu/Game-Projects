active = 0;
letter = "d"; //This is the letter being used.