active = 0;
letter = "Q"; //This is the letter being used.