playername = global.playername;
playername = string_lower(playername);