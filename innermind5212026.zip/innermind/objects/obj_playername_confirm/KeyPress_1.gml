global.playername = string(global.playername);

if (keyboard_check(global.cancel_key1) || keyboard_check(global.cancel_key2))
{
	if (string_length(global.playername)) > 0
		{
		global.playername = string_delete(global.playername, string_length(global.playername), 1);
		}
}