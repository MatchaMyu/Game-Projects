// Get the player's input
playername = global.playername; // Replace with your function to get the player name