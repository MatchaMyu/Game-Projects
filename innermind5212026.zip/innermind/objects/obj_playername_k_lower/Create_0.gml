active = 0;
letter = "k"; //This is the letter being used.