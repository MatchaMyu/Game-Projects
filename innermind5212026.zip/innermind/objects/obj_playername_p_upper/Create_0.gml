active = 0;
letter = "P"; //This is the letter being used.