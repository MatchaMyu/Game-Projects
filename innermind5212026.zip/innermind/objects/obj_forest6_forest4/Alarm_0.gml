global.playerx = 112;
global.playery = 432;
room_goto(rm_forest4);