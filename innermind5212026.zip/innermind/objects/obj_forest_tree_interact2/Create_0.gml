thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 1;
face = obj_textbox_image_parent;
fulltext = "* It's just a tree";