global.playerx = 96;
global.playery = 352;
room_goto(rm_forest5);