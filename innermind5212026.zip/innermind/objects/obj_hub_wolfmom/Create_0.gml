nearme = 64;

spoken = 0;