if distance_to_object(obj_player) < nearme
{
	if !instance_exists(obj_textbox_box)	
	{	
		with instance_create_layer(x, y, "Instances_1",obj_textbox_box)
		{
			switch (other.spoken)
			{
			case 0: fulltext = "*Where did you come from?"; break;
			default: fulltext = "*I don't have a name yet..."; break;
			}
		}
	}
	else
	{
	instance_destroy(obj_textbox_box);
	}
}
