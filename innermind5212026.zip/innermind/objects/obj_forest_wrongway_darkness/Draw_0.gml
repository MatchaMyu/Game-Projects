//I guess this draws a circle around the player.
//Also darkness around the player too.
surface_set_target(lighting_surface);

var cam_x = camera_get_view_x(view_camera[0]);
var cam_y = camera_get_view_y(view_camera[0]);
var cam_w = camera_get_view_width(view_camera[0]);
var cam_h = camera_get_view_height(view_camera[0]);

var px = obj_player.x;
var py = obj_player.y;

// Draw full darkness
// Cut out the circle

draw_clear_alpha(c_black, 0.8);

draw_set_color(c_black);
draw_set_alpha(1);
draw_rectangle(cam_x, cam_y, cam_x + cam_w, cam_y + cam_h, false);


gpu_set_blendmode(bm_subtract);
draw_sprite(spr_forest_hole, 0, px, py);
gpu_set_blendmode(bm_normal);

surface_reset_target();
draw_surface(lighting_surface, camera_get_view_x(view_camera[0]), camera_get_view_y(view_camera[0]));

