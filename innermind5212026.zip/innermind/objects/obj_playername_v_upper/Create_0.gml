active = 0;
letter = "V"; //This is the letter being used.