active = 0;
letter = "J"; //This is the letter being used.