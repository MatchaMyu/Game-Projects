draw_set_font(fnt_playername);
draw_text_transformed(x,y,"Name: " + global.playername,1.5,1.5,0);