active = 0;
letter = "N"; //This is the letter being used.