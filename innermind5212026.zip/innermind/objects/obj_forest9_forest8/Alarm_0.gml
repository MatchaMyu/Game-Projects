global.playerx = 2960;
global.playery = 320;
room_goto(rm_forest8);