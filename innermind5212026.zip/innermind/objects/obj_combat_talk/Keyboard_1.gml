if (keyboard_check_pressed(global.left) || keyboard_check_pressed(global.left2)) && active = 1
{
active = 0
with obj_combat_act
	{
	alarm_set(0,1);
	}
}

if (keyboard_check_pressed(global.right) || keyboard_check_pressed(global.right2)) && active = 1
{
active = 0
with obj_combat_item
	{
	alarm_set(0,1);
	}
}