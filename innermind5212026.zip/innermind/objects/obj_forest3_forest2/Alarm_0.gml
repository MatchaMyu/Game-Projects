global.playerx = 1824;
global.playery = 1008;
room_goto(rm_forest2);