if active = 1
{
	if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
	{
	instance_create_depth(room_width/2,room_height/2,-999,obj_ring_damage);

	instance_destroy(obj_combat_act_choices); //This is already knowingly created.
	}
}