global.playerx = 672;
global.playery = 1408;
room_goto(rm_forest2);