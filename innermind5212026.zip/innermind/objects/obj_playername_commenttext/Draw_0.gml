draw_set_font(fnt_playername);

if (enable == 1)
{
	switch name
	{
		case "myu":
			switch myupicked
			{
				case 1: draw_text(x,y,"Spoiler alert: No."); break;
				case 2: draw_text(x,y,"I said no."); break;
				case 3: draw_text(x,y,"Take this name instead."); break;
				default: draw_text(x,y,"That's it. Back to the title screen with you."); break;
			}
			break;

		case "silver":
			draw_text(x,y,"You're not picking MY name!"); break;
	}
}

//Special case names
switch string_lower(global.playername)
{
	case "luna":
		draw_text(x,y,"HAAAIII CAT!");
		break;
	case "cookie":
		draw_text(x,y,"COOKIE APPROVES! COOKIES NAME!");
	case "gold":
		draw_text(x,y,"An interesting choice. Sure. She'll be mad, though.");
		break;
}
