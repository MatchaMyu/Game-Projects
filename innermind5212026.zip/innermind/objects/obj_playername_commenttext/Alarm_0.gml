enable = 1;
if name = "myu"
{
	if myupicked = 2
	{
		if global.playername != "NotMyu" 
		{
			global.playername = "NotMyu";
		}
	}
	if myupicked >= 3
	{
		with obj_nameentry_done
		{
			disable = 1;
		}
		with obj_playername_selector
		{
			disable = 1;
		}
	
		alarm_set(2,180);
		myupicked ++; //Because this event exits to prevent alarm 1 from occuring, gotta set the variable here to draw it.
		exit;
	}
myupicked ++;
}
alarm_set(1,180);