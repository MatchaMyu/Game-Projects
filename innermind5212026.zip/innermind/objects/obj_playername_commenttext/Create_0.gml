enable = 0;
name = "";
myupicked = 0;