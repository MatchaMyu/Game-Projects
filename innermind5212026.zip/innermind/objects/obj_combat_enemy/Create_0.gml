global.battle_result = ""; //Set to null at the beginning of each combat.

//REMEMBER TO UPDATE global.enemy_results IN THE SCR_BATTLERESULTSFLAGS FOR EVERY ENCOUNTER
switch global.enemy
{
	case 101: sprite_index = spr_cookie; face = spr_cookie_face; //Cookie Tutorial
	
	with instance_create_layer(x, y, "Instances_text",obj_combat_enemyspeak)
	{
	fulltext = "* Oh, is this a battle screen? Cooke has never seen this before!"
	+"^3 ...^3 ...^3 Cookie can't move.^6 It must be not Cookie's turn then, right?";
	face = other.face;
	}
	alarm_set(0,1);
	break;
	//End case 101/Cookie Tutorial.
	
	default: break;
	
	
}