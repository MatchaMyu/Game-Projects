//Disables player turn.
obj_combat_blank.playerturn = 0;
obj_combat_act.active = 0;