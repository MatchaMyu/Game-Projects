active = 0;
letter = "F"; //This is the letter being used.