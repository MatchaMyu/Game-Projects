var cx = x;
var cy = y;

// ring sizes
var crit_inner = target_r - window_crit;
var crit_outer = target_r + window_crit;

var ok_inner = target_r - window_ok;
var ok_outer = target_r + window_ok;

draw_set_alpha(0.60);

// =====================
// OUTER MISS ZONE
// =====================

draw_set_color(c_red);
draw_circle(cx, cy, max_r, false);

// =====================
// OK ZONE
// =====================

draw_set_color(c_yellow);
draw_circle(cx, cy, ok_outer, false);

draw_set_color(c_red);
draw_circle(cx, cy, ok_inner, false);

// =====================
// CRIT ZONE
// =====================
draw_set_color(c_green);
draw_circle(cx, cy, crit_outer, false);

draw_set_color(c_yellow);
draw_circle(cx, cy, crit_inner, false);

draw_set_alpha(1);

//outline
draw_set_color(c_red);
draw_circle(cx, cy, max_r, true);

//Moving/base ring on top
draw_set_color(c_black);
draw_circle(cx, cy, r, true);

// echo pulse on hit
if (echo_alpha > 0) {
    draw_set_alpha(echo_alpha);

    if (attackresult = "CRIT") {
		draw_set_color(c_green); //CRIT
    } else if (attackresult = "OK") {
		draw_set_color(c_yellow); //OK
    } else if (attackresult = "MISS") {
        draw_set_color(c_red); //MISS
    }
	draw_circle(cx, cy, max_r, false);
    draw_set_alpha(1);

}

// result text
draw_set_color(c_white);
draw_text(cx + 110, cy - 10, "VAR: " + string(variant));
draw_text(cx + 110, cy + 8,  "RES: " + string(attackresult));
