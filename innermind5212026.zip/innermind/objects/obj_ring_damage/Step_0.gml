var dt = delta_time * 0.000001; // correct: microseconds to seconds

// animate radius
r += dr * pulsespeed * dt;

// bounce or wrap
if (pulsate) {
    if (r >= max_r) { r = max_r; dr = -1; }
    if (r <= min_r) { r = min_r; dr = +1; }
} else {
    if (r >= max_r) { r = min_r; dr = +1; } // reset
}

// input. Default is space
if (cooldown <= 0 && keyboard_check(global.confirm_key1)) || (cooldown <= 0 && keyboard_check(global.confirm_key2)) {
    var diff = abs(r - target_r);

    if (diff <= window_crit) {
        attackresult = "CRIT";
        echo_r = r; echo_alpha = 1;
        //Audio can go here
    } else if (diff <= window_ok) {
        attackresult = "OK";
        echo_r = r; echo_alpha = 1;
        //Audio can go here
    } else {
        attackresult = "MISS";
        echo_r = r; echo_alpha = 1;
        //Audio can go here
    }
    cooldown = 60; //not needed for the game, but can work as a safety measure
	alarm_set(0,10);
}

// cooldown & echo fade
cooldown -= 1;
echo_alpha = max(0, echo_alpha - 2 * dt); // quick fade
