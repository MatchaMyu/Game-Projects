	with obj_combat_blank
	{
		attackresult = other.attackresult;
		playerturn = 0;
		act = 1;
		alarm_set(0,1);
	}
instance_destroy();