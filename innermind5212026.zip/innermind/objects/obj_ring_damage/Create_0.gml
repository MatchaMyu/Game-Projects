min_r = 12;
max_r = 64;
pulsespeed = 50;
pulsate = true;
variant = 1;            // 0=SMALL, 1=MEDIUM, 2=MAX. This places the 'crit/hit' zone.
window_crit = 6;        // +/- pixels for CRIT. Higher = more forgiving.
window_ok   = 12;       // +/- pixels for OK. Higher = more forgiving.

/// STATE
r = min_r;              // current radius
dr = +1;                // direction of growth (+1 out, -1 in)
cooldown = 30;           // small lockout after a press

/// TARGETS per variant
switch (variant) {
    case 0: target_r = lerp(min_r, max_r, 0.20); break; // SMALL ~20%
    case 1: target_r = lerp(min_r, max_r, 0.50); break; // MEDIUM 50%
    case 2: target_r = max_r;                 break;
}

echo_alpha = 0;
echo_r = 0;

attackresult = "";   // "CRIT", "OK", "MISS"
