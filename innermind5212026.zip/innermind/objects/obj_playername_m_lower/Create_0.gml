active = 0;
letter = "m"; //This is the letter being used.