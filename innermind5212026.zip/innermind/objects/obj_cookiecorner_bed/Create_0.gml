thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 2;
face = spr_cookie_face;
interact = 0;
fulltext = "\"Cookie sleeps there.\"";
fulltext1 = "\"Uumm...Cookie doesn't think there's rom for both of us.\"";
talkedwith = 0;

//Interact changes the fulltext in the key press event.