if talkedwith > 0
{
fulltext = "* You see a second, albeit smaller pillow.";
face = spr_unknown_face;
maxspoken = 1;
fulltext1 = undefined;
}

if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{

if distance_to_object(obj_player) < 96
{
 scr_talking(id);
}

}
