if active = 1
{
	if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
	{
		if !instance_exists(obj_combat_item_window)
		{
			with instance_create_depth(x,y,-10,obj_combat_item_window)
			{
				item = 1;
			}
			active = 0;
		}
	}
}