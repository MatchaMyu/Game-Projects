active = 0;
letter = "p"; //This is the letter being used.