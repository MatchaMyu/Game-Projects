if talkedwith > 0
{
face = spr_unknown_face;
fulltext = "* The fire is made out of cardboard and crayon.";
maxspoken = 1;
fulltext1 = undefined;
}

if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{

if distance_to_object(obj_player) < 96
{
 scr_talking(id);
}

}
