thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 2;
face = spr_cookie_face;
interact = 0;
fulltext = "\"Cookie made a FIGHT box cause Cookie wants to be a brave!\"";
fulltext1 = "\"Can you show Cookie how to be a brave?\"";
talkedwith = 0;

//Interact changes the fulltext in the key press event.