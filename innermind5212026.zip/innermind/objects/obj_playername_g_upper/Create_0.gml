active = 0;
letter = "G"; //This is the letter being used.