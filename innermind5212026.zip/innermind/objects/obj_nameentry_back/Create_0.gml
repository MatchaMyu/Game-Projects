active = 0;
global.playername = string(global.playername);