if active = 1
{
	global.playername = string(global.playername); //I guess we use this cause GMS2 is fucky wucky
	if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
	{
	if (string_length(global.playername)) > 0
		{
		global.playername = string_delete(global.playername, string_length(global.playername), 1);
		}
	}
}