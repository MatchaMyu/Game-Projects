if active = 0
{
	draw_sprite(spr_nameentry_back,0,x,y)
}
if active = 1
{
	draw_sprite(spr_nameentry_back,1,x,y)
}