if place_meeting(x,y,obj_playername_selector)
{
active = 1;
}
else
{
active = 0;
}