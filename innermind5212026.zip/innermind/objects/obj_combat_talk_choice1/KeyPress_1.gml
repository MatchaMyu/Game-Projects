if active = 1
{
	if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
	{
		
	with obj_combat_blank
	{
		playerturn = 0;
		talk = 1;
		alarm_set(0,1);
	}
	
	instance_destroy(obj_combat_choices); //This is already knowingly created.
	}
}