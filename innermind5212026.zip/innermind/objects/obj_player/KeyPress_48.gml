//Debug Key. Disabled for prototype


room_goto(rm_forest4);
global.story = 2; //Story setting logic.