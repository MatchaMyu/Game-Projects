pause = 0; //disables movement when set to 1.
camerafollow = 0; //This is set to 0 by default. When it is set to 1, the camera will NOT FOLLOW THE PLAYER
player_camera = view_camera[0]

if global.playerx && global.playery != -1
{
x = global.playerx
y = global.playery
global.playerx = -1;
global.playery = -1;
}

//half_view_width = view_wview[0] / 2;
//half_view_height = view_hview[0] / 2;

instance_create_depth(x,y,-99,obj_fadein);
depth = -5;

global.talkdelay = 0;

//TODO: spawn logic in each transition. 

//Push logic for the push logic puzzles
push_direction_x = 0;
push_direction_y = 0;