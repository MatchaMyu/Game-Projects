if (keyboard_check(global.menu_key1) || keyboard_check(global.menu_key2))
{

	if !instance_exists(obj_menu_screen) && (pause = 0) && (global.pause = false) && (global.scene_pause = false)
	{
	 if (view_get_visible(0))
		{
		instance_create_depth(camera_get_view_x(player_camera)+32,camera_get_view_y(player_camera)+32,-80,obj_menu_screen);
		 }
		 else
		{
		instance_create_depth(32,32,-80,obj_menu_screen); //In case I forget to add a camera.
		}
	pause = 1;
	}
	else if instance_exists(obj_menu_screen)
	{
	instance_destroy(obj_menu_screen);
	pause = 0;
	}
}

if (keyboard_check(global.quit_key1))
{
game_end();
}