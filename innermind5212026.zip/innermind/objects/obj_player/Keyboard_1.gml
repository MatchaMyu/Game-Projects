//Left movement.
if (keyboard_check(global.left) || keyboard_check(global.left2))
{
	push_direction_x = -1;
	push_direction_y = 0;
	if (pause = 0) && (global.pause = false) && (global.scene_pause = false)
	{
		if place_free(x - 3,y)
		{
		x = x - 3;
		}
	}
}

//Up movement
if (keyboard_check(global.up) || keyboard_check(global.up2))
{
	push_direction_x = 0;
	push_direction_y = -1;
	if (pause = 0) && (global.pause = false) && (global.scene_pause = false)
	{
		if place_free(x, y - 3)
		{
		y = y - 3;
		}
	}
}

//Right movement
if (keyboard_check(global.right) || keyboard_check(global.right2))
{
	push_direction_x = 1;
	push_direction_y = 0;
	if (pause = 0) && (global.pause = false) && (global.scene_pause = false)
	{
		if place_free(x + 3,y)
		{
		x = x + 3;
		}
	}
}

//Down movement
if (keyboard_check(global.down) || keyboard_check(global.down))
{
	push_direction_x = 0;
	push_direction_y = 1;
	if (pause = 0) && (global.pause = false) && (global.scene_pause = false)
	{
		if place_free(x, y + 3)
		{
		y = y + 3;
		}
	}
}