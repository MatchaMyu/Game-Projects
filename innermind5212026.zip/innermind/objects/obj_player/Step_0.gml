if (camerafollow == 0)
{
    var view_w = camera_get_view_width(player_camera);
    var view_h = camera_get_view_height(player_camera);
    
    var half_w = view_w / 2;
    var half_h = view_h / 2;

    var cam_x = x - half_w;
    var cam_y = y - half_h;

    cam_x = clamp(cam_x, 0, room_width - view_w);
    cam_y = clamp(cam_y, 0, room_height - view_h);

    // Move the camera!
    camera_set_view_pos(player_camera, cam_x, cam_y);
}

global.talkdelay--;