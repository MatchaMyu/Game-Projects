//TODO: Reuse for Mountain except it moves until it hits a wall?
moving = false;
target_x = x;
target_y = y;
grid_size = 48; //Snappy logic.
move_speed = 4;

//Logic in case it gets screwy uppy
x = round(x / grid_size) * grid_size;
y = round(y / grid_size) * grid_size;