// No pushing during pause states
if (global.pause || global.scene_pause)
{
    exit;
}


// Make sure player exists
if (!instance_exists(obj_player))
{
    exit;
}

//Snappy movement logic.
if (moving)
{
    var dist = point_distance(x, y, target_x, target_y);

    if (dist <= move_speed)
    {
        x = target_x;
        y = target_y;
        moving = false;
    }
    else
    {
        x = x + lengthdir_x(move_speed, point_direction(x, y, target_x, target_y));
        y = y + lengthdir_y(move_speed, point_direction(x, y, target_x, target_y));
    }

    exit;
}

//Push left.
if distance_to_object(obj_player) < 4 && (obj_player.push_direction_x == 1)
{
	if obj_player.x < x
	{
		
		target_x = x + 6;
		target_y = y;
		if !place_meeting(target_x, target_y, obj_wall_master)
		{
		moving = true;
		}
		
	}
}

//Push right.
if distance_to_object(obj_player) < 4 && (obj_player.push_direction_x == -1)
{
	if obj_player.x > x
	{
		target_x = x - 6;
		target_y = y;
		if !place_meeting(target_x, target_y, obj_wall_master)
		{
		moving = true;
		}
	}
}

//Push up
if distance_to_object(obj_player) < 4 && (obj_player.push_direction_y == -1)
{
	if obj_player.y > y
	{
		target_y = y - 6;
		target_x = x;
		if !place_meeting(target_x, target_y, obj_wall_master)
		{
		moving = true;
		}
	}
}

//Push down
if distance_to_object(obj_player) < 4 && (obj_player.push_direction_y == 1)
{
	if obj_player.y < y
	{
		target_y = y + 6;
		target_x = x;
		if !place_meeting(target_x, target_y, obj_wall_master)
		{
		moving = true;
		}
	}
}