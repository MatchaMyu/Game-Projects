active = 0;
letter = "j"; //This is the letter being used.