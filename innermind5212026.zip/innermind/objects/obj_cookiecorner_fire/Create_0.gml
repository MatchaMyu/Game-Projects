thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 2;
face = spr_cookie_face;
interact = 0;
fulltext = "\"That's Cookie's fire!\"";
fulltext1 = "\"Careful, it's hot!\"";
talkedwith = 0;

//Interact changes the fulltext in the key press event.