fulltext = "I am Error";

displaytext = "";

textspeed = 0.5;
counter = 0;
delaycounter = 0;

obj_player.pause = 1;

instance_create_depth(x-9999,y-99999,-100,obj_textbox_image_parent);