if disable == 0
{
	if x > 208 && y != 632
	{
		x=x-48;
	}
	else if y == 632
	{
		x = 208; //Goes to DONE
	}
	else
	{
		x=784;
	}
}