if disable == 0
{
	if y > 440
	{
		y=y-48;
	}
	else
	{
		y=584;
	}
}