if disable == 0
{
	if x < 784 && y != 632
	{
		x=x+48;
	}
	else if y == 632 //Goes to BACK
	{
		x = 304;
	}
	else
	{
		x=208;
	}
}