if disable == 0
{
	if y < 584
	{
		y = y + 48;
	}
	else if y == 632
	{
		y = 440;
	}
	else
	{
		x = 208;
		y = 632;
	}
}