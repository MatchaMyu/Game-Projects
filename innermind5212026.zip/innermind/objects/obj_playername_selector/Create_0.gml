disable = 0;
x = x;
y = y;