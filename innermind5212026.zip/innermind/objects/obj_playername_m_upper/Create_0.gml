active = 0;
letter = "M"; //This is the letter being used.