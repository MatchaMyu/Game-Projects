draw_self();
draw_set_font(fnt_text_combat);
if active = 1
{
	draw_set_color(c_yellow);
}
else
{
draw_set_color(c_white);
}
draw_text(x+16, y+12,"Act");