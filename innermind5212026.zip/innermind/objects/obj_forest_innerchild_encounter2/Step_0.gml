if enable = 1
{
	x = x-6;
}