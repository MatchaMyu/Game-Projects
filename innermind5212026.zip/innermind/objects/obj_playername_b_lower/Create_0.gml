active = 0;
letter = "b"; //This is the letter being used.