active = 0;
letter = "w"; //This is the letter being used.