active = 0;
letter = "u"; //This is the letter being used.