if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{

	if displaytext != fulltext
	{
	textspeed = 5;
	//fulltext = string_replace_all(fulltext, "^", "");

	caretposition = string_pos("^", fulltext);

	while (caretposition != 0 && caretposition < string_length(fulltext) - 1) 
	{
		textBeforeCaret = string_copy(fulltext, 1, caretposition - 1);
		textAfterCaret = string_copy(fulltext, caretposition + 2, string_length(fulltext));
		fulltext = textBeforeCaret + textAfterCaret;
		 caretposition = string_pos("^", fulltext);
	}
	
	}
	else
	{
		if global.cutscene = 0
		{
	
		}	
	}
}