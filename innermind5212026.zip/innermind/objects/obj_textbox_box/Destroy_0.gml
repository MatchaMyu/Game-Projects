if instance_exists(obj_player)
{
	obj_player.pause = 0;
}