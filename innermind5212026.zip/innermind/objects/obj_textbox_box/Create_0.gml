fulltext = "I am Error"; //Text not passed properly.

face = spr_error_face; //Face not passed properly.
face1 = spr_error_face; //Face not passed properly.
face2 = spr_error_face; //Face not passed properly.
fulltextdisplay = 0;
displaytext = "";

textspeed = 0.5;
counter = 0;

if instance_exists(obj_player) //Sanity check
{
obj_player.pause = 1;
}

delaycounter = 0; // Counter for the delay

caretposition = "null";
textBeforeCaret = "null";
textAfterCaret = "null";

specialWord = "SAVE";
specialColor = c_yellow;
normalColor = c_white;

specialWord2 = "FIGHT";
specialColor2 = c_red;

with instance_create_depth(x-99999,y-99999,-100,obj_textbox_image_parent)
{
face = other.face;
face1 = other.face1;
face2 = other.face2;
}