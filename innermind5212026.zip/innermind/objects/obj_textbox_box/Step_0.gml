if (counter < string_length(fulltext)) {

	//short pause
    if (string_char_at(fulltext, counter) == "$" && delaycounter <= 0) {
        delaycounter = 15;
        fulltext = string_delete(fulltext, counter, 2); // Deletes '^'
    }

	//medium pause
    if (string_char_at(fulltext, counter) == "^" && delaycounter <= 0) {
        delaycounter = 30;
        fulltext = string_delete(fulltext, counter, 2); // Deletes '^'
    }
	
	//long pause
    if (string_char_at(fulltext, counter) == "&" && delaycounter <= 0) {
        delaycounter = 60;
        fulltext = string_delete(fulltext, counter, 2); // Deletes '^'
    }

    if (delaycounter > 0) {
        delaycounter--; // Decrement delay counter
    } else {
        counter += textspeed; // Increment text counter
    }

    // Displays text
    displaytext = "";
    for (var i = 1; i <= counter; i++) 
	{
        var currentChar = string_char_at(fulltext, i);
		//Hides pause characters
        if ((currentChar !="^") && (currentChar !="&") && (currentChar !="$")) 
		{
            displaytext += currentChar;
        }
    }
	
}

 if (view_get_visible(0))
 {
x = camera_get_view_x(view_camera[0]) + 200;
y = camera_get_view_y(view_camera[0]) + 520;
 }
 else
{
	if instance_exists(obj_player) //sanity check.
	{
	x = camera_get_view_width(player_camera) + 200;
	y = camera_get_view_height(player_camera) + 520;
	}
}

global.displaytext = displaytext;
global.fulltext = fulltext;