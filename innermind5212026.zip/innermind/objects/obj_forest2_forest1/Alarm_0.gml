global.playerx = 192;
global.playery = 128;
room_goto(rm_forest);
