if active = 0
{
	draw_sprite(spr_nameentry_done,0,x,y)
}
if active = 1
{
	draw_sprite(spr_nameentry_done,1,x,y)
}