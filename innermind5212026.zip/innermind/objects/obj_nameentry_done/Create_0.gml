active = 0;
disable = 0;

//Keep all names lowercase, otherwise this won't check the name properly.
specialnames = ["myu", "silver"];