if (!variable_global_exists("playername")) {
    global.playername = "";
}

if (keyboard_check_pressed(global.confirm_key1) || keyboard_check_pressed(global.confirm_key2))
{
	if active = 1 && disable = 0
	{
		for (var i = 0; i < array_length(specialnames); i++) 
		{
			if (string_lower(global.playername) == specialnames[i]) 
			{
				with (obj_playername_commenttext)
				{
					name = string_lower(global.playername);
					alarm_set(0,1);
				}
			global.playername = "";
			exit;
			}
		}
	room_goto(rm_storyintro);
	}
}