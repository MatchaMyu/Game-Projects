global.playerx = 560;
global.playery = 624;
room_goto(rm_forest4);