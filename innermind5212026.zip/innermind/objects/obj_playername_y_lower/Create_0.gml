active = 0;
letter = "y"; //This is the letter being used.