if talkedwith > 0
{
fulltext = "\"I- Cookie means Cookie made the gate Cookieself!\"";
maxspoken = 1;
fulltext1 = undefined;
}

if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{

if distance_to_object(obj_player) < 64
{
 scr_talking(id);
}

}