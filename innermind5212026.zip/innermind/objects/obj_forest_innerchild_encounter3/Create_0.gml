if global.story <= 2
{
instance_destroy();
}


thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 4;
face = spr_cookie_face;
talkedwith = 0;

if global.milkget = 1
{
	fulltext = "\"Have you seen Milk?\"";
	fulltext1 = "\"Oh! You have Milk! Gimmie!\"";
}
else
{
	fulltext = "\"Yay Cookie found the Milk! Wait...\"";
	fulltext1 = "\"You saw it earlier? Why didn't you pick it up?\"";
}

fulltext2 = "\"Cookie's gate fell and went boom...\"";
fulltext3 = "\"Cookie means um...Cookie opened the gate!\"";