active = 0;
letter = "R"; //This is the letter being used.