fade_alpha = 0; // Start fully black
fade_speed = 0.1; // Customize how fast it fades
fading_in = false;
