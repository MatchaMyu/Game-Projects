obj_player.pause = 0;
image_alpha = 1;