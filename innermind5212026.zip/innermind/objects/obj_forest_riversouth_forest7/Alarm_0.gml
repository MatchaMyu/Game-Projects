global.playerx = 576;
global.playery = 656;
room_goto(rm_forest7);