active = 0;
letter = "H"; //This is the letter being used.