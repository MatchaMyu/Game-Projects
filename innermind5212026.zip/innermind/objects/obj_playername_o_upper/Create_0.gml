active = 0;
letter = "O"; //This is the letter being used.