if (keyboard_check(global.cancel_key1) || keyboard_check(global.cancel_key2))
	{
		with obj_combat_talk
			{
				active = 1;
			}

		instance_destroy();
	}