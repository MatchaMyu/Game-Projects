if talk = 1
{
	switch global.enemy
		{
		case 101: 
		with instance_create_depth(x,y,-19,obj_combat_talk_choice1) 
			{
			choice = 1;
			active = 1;
			}
		with instance_create_depth(x,y+32,-19,obj_combat_talk_choice2) 
			{
			choice = 1;
			active = 0;
			}
		break;
		default: break;
		}
}