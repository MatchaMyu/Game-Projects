if (fleeing) {
    obj_combat_player.x -= 6;

    if (obj_combat_player.x < -32) {
        room_goto(global.currentroom);
    }
}