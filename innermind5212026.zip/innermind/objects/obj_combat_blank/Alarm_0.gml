//This functions as the players action.

//TODO: Create a switch function based on the enemy. Can use a script because it's gonna get messy.

if (talk == 1)
{
	with instance_create_layer(x, y, "Instances_text",obj_combat_playertext)
	{
	//TODO: Global enemy should change the text.
	fulltext = "* You tell a joke. It falls flat because you didn't provide context."; break;
	}
}

if (act == 1)
{
	with instance_create_layer(x, y, "Instances_text",obj_combat_playertext)
	{
	//TODO: Global enemy should change the text.
	fulltext = "* You make an attack. But this isn't programmed in the game fully yet."; break;
	}

	
}

playerturn = 1;

//Resets vars for next turn.
act = 0;
talk = 0;
