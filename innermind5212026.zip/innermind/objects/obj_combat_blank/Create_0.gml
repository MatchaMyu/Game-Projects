playerturn = 1; //1 = playerturn. This is always true at the start of combat.

act = 0; //determines what 'act' result the player took under ACT
talk = 0; //Determines what 'talk' result the player took. Under TALK

turncount = 0; //Increase during enemy's turn.
canflee = false; //If set to false, can't flee the battle. (or something happens when trying to)
fleeing = false; //handled in the fleeing script.

depth = 299;

attackresult = "";   // "CRIT", "OK", "MISS" Controlled by ring damage.