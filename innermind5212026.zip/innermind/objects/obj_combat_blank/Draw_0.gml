/// @description Draws Background based on enemy.

switch global.enemy
	{
	case 101: //Cookie

	draw_sprite(spr_back_combat_forest,0,0,0);
	break;
	
	default:
	break;
	}