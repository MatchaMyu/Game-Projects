/// @description Enemy response.

scr_enemyresponse();