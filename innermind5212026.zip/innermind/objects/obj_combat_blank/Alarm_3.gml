//end of turn

playerturn = 1;
act = 0;
talk = 0;

with obj_combat_player
{
movement = 0;
}

with obj_combat_act
{
active = 1;
}