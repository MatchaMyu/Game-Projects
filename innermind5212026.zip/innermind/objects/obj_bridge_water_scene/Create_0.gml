if global.story >= 5
{
	instance_destroy();
}

spoken = 0;
active = 0;
enabled = 0;
textchange = 0;
talkedwith = 0;

thespecial = 0; //Triggers special events in the script talking
maxspoken = 1;
face = obj_textbox_image_parent;

switch (textchange) {
	case 0: fulltext = "\"Wade! Don't you wanna try crossing the bridge?\""; break;
	
	case 1: fulltext = "\"Cookie really thinks you should try the bridge!\""; break;

	case 2: fulltext = "\"Awww please try the bridge? It's fun!\""; break;

	default: fulltext = "\"Cookie reached an error\"";break;
}