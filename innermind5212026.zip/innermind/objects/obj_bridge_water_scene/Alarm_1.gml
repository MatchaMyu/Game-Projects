obj_player.hspeed = 0;
spoken = 0;
textchange = textchange + 1;
enabled = 0;

switch (textchange) {
	case 0: fulltext = "\"Wade! Don't you wanna try crossing the bridge?\""; break;
	
	case 1: fulltext = "\"Cookie really thinks you should try the bridge!\""; break;

	case 2: fulltext = "\"Awww please try the bridge? It's fun!\""; break;

	default: fulltext = "\"Cookie reached an error\"";break;
}