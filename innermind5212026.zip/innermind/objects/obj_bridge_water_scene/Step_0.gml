if enabled = 0 && textchange < 3
{
	if (place_meeting(x, y, obj_player))
	{
	 scr_talking(id);
	 enabled = 1;
	}
}

if talkedwith = 1
{
	alarm_set(0,1);
}