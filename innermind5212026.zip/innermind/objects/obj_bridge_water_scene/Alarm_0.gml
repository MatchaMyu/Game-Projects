if instance_exists(obj_player) //Sanity check
{
	obj_player.hspeed = -5;
	alarm_set(1, 10);
}
talkedwith = 0;