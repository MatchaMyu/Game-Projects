if (enabled == 1)
{
	if (keyboard_check_pressed(global.confirm_key1) || keyboard_check_pressed(global.confirm_key2))
{
 scr_talking(id);
}

}