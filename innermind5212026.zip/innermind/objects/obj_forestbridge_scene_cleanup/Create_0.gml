instance_destroy(obj_bridge_scene_end);
instance_destroy(obj_bridge_scene_start);
instance_destroy(obj_bridge_water_scene);
instance_destroy(obj_bridge_water_scene_end);
instance_destroy();