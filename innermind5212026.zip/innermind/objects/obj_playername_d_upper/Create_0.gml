active = 0;
letter = "D"; //This is the letter being used.