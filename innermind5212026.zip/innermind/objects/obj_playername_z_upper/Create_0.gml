active = 0;
letter = "Z"; //This is the letter being used.