active = 0;
letter = "K"; //This is the letter being used.