target = 840;
endscene = 0;