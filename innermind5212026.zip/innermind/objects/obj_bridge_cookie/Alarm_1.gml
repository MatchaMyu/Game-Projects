//if instance_exists(obj_bridge_scene_end)
//{
//instance_destroy(obj_bridge_scene_end);
//}
global.scene_pause = false;