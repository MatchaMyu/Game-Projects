if x >= target && endscene = 0
{
	speed = 0;
	endscene = 1;
	alarm_set(1,1);
}