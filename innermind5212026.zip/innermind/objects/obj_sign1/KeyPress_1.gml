if talkedwith > 0
{
fulltext = "You interacted with me again!";
maxspoken = 1;
fulltext1 = undefined;
if talkedwith > 10
	{
	fulltext = "Okay. Your obsession with interactions is getting disturbing.";
	maxspoken = 1;
	fulltext1 = undefined;
	}
}

if (keyboard_check_pressed(global.confirm_key1) || keyboard_check_pressed(global.confirm_key2))
{

if distance_to_object(obj_player) < 64
{
 scr_talking(id);
}

}
