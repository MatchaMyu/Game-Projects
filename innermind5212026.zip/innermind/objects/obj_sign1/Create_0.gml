thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 2;
face = spr_sign_face;
fulltext = "*This is a sign. You can interact with signs by pressing the interact button.";
fulltext1 = "It's that button you just pressed.";
talkedwith = 0;

//Interact changes the fulltext in the key press event.