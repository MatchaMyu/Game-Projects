active = 0;
letter = "I"; //This is the letter being used.