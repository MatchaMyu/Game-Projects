draw_set_font(fnt_playername);
draw_text(x,y,"Yes");