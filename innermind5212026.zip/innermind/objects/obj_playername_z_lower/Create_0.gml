active = 0;
letter = "z"; //This is the letter being used.