fulltext = "I am Error";

displaytext = "";

textspeed = 0.5;
counter = 0;

delaycounter = 0; // Counter for the delay

caretposition = "null";
textBeforeCaret = "null";
textAfterCaret = "null";