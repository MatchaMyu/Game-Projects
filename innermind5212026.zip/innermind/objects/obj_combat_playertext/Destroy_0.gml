//Enemy Response.
with obj_combat_blank
{
alarm_set(1,1);
}