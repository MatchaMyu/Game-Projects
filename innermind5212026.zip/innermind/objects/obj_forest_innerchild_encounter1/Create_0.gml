if global.story = 0
{
path_start(pth_innerchildstart_encounter1,10,path_action_stop,false);
global.story = global.story + 1;
}
else
{
instance_destroy();
}