active = 0;
letter = "U"; //This is the letter being used.