active = 0;
letter = "B"; //This is the letter being used.