playerhp_percent = 100;
bar_width = 128;