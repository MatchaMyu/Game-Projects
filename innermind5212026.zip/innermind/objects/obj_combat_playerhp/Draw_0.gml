draw_set_color(c_green);
draw_rectangle(x, y, x + bar_width, y + 30, true);
draw_rectangle(x, y, x + (bar_width * playerhp_percent), y + 30, false);
draw_set_color(c_white);


draw_self();
draw_set_font(fnt_text_combat);

draw_set_color(c_green);
draw_text(x, y-32,"HP:");
draw_text(x+36, y-32, string(global.playerhp_current) + "/" + string(global.playerhp_max) );