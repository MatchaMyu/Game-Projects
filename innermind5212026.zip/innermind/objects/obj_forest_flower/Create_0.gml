thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 1;

fulltext = "* It feels like the yellow flower wants to teach you about LOVE...^3 it fills you with confusion.";

//Fulltext is in Key Press because the global.story variable changes, changing how you interact with this!