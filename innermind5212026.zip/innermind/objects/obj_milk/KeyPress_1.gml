if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{

if distance_to_object(obj_player) < 8 && global.milkget = 0
{
global.milkget = 1;
ds_list_add(global.inventory, "Milk");
 scr_talking(id);
}
else if distance_to_object(obj_player) < 8 && global.milkget = 1
{
 scr_talking(id);
}

}