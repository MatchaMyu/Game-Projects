if global.milkget = 1 && !instance_exists(obj_textbox_box)
{
instance_destroy();
}