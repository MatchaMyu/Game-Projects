if global.story > 2
{
instance_destroy();
}

if global.milkget = 1
{
instance_destroy();
}
thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 1;
fulltext = "* You^3 got^3 the^3 milk!";
face = spr_milk_face;