active = 0;
letter = "C"; //This is the letter being used.