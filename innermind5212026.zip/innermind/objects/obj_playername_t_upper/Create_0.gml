active = 0;
letter = "T"; //This is the letter being used.