active = 1;
letter = "A"; //This is the letter being used.