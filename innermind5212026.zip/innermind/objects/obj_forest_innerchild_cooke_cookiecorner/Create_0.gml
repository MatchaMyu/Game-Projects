thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 3;
face = spr_cookie_face;
fulltext = "\"Welcome to Cookie's Corner! Cookie gots four corners here!\"";
fulltext1 = "\"Cookie doesn't know what it is...\"";
fulltext2 = "\"But Cookie feels pretty SAVE here.\"";
