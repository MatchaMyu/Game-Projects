thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 3;
face = obj_textbox_image_parent;
fulltext = "* It's just a tree";
fulltext1 = "* It's just a test";
fulltext2 = "* It's just another test";
