thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 1;

fulltext = "Error"

//Fulltext is in Key Press because the global.story variable changes, changing how you interact with this!