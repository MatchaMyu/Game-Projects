active = 0;
letter = "r"; //This is the letter being used.