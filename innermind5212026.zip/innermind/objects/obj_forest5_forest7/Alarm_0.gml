global.playerx = 112;
global.playery = 384;
room_goto(rm_forest7);