if (keyboard_check_pressed(global.down) || keyboard_check_pressed(global.down2)) && active = 1
{

if instance_exists(obj_combat_talk_choice1)
	{
	
	with obj_combat_talk_choice1
	{
	alarm_set(0,1);
	}
	active = 0;
	}
}

if (keyboard_check_pressed(global.up) || keyboard_check_pressed(global.up2)) && active = 1
{
if instance_exists(obj_combat_talk_choice1)
	{
	
	with obj_combat_talk_choice1
	{
	alarm_set(0,1);
	}
	active = 0;
	}
}