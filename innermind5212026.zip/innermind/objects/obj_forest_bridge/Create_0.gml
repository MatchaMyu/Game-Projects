if global.story >= 5
{
	instance_destroy();
}