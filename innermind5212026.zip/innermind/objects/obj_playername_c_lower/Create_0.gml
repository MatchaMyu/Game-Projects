active = 0;
letter = "c"; //This is the letter being used.