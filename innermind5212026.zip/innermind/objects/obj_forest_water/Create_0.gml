if global.story >= 5
{
	solid = false;
}