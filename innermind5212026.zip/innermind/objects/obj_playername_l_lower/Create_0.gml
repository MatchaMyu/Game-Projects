active = 0;
letter = "l"; //This is the letter being used.