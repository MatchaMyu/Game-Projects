thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 2;
face = obj_textbox_image_parent;
fulltext = "\"Promise you'll come back, okay?\"";
talkedwith = 0;
alarm_set(0,120);
//Interact changes the fulltext in the key press event.