active = 0;
letter = "x"; //This is the letter being used.