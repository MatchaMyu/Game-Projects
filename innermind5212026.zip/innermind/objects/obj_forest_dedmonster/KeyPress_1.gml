if talkedwith > 0
{
fulltext = "* You are impressed Cookie can draw on grass.";
maxspoken = 1;
fulltext1 = undefined;
}

if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{

if distance_to_object(obj_player) < 64
{
	scr_talking(id);
}

}