image_speed = 0;
image_index = 0;

talkedwith = 0;

thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 1;


face = obj_textbox_image_parent;

fulltext = "Cookie absolutely made that monster DED! Don't worry about it! Cookie SUPER strong!";