//Enemy Response.

//It's NOT the players turn after the text. Generates attack.
if playerturn = 1
{
	scr_enemy_attack(global.enemy);
	obj_combat_player.movement = 1;
}

//It's the players turn after the text.
if playerturn = 0
{
obj_combat_blank.playerturn = 1;
obj_combat_act.active = 1;
}

if endcombat = 1
{
	room_goto(global.currentroom);
}