if (counter < string_length(fulltext)) {
    // Check if current character is '^' and if we are not already in delay
    if (string_char_at(fulltext, counter) == "^" && delaycounter <= 0) {
        delaycounter = 30; // Start delay
        fulltext = string_delete(fulltext, counter, 2); // Delete '^'
    }

    if (delaycounter > 0) {
        delaycounter--; // Decrement delay counter
    } else {
        counter += textspeed; // Increment text counter
    }

    // Construct display text, excluding '^'
    displaytext = "";
    for (var i = 1; i <= counter; i++) 
	{
        var currentChar = string_char_at(fulltext, i);
        if (currentChar != "^") 
		{
            displaytext += currentChar;
        }
    }
}

x = 160;
y = 0;


global.displaytext = displaytext;
global.fulltext = fulltext;