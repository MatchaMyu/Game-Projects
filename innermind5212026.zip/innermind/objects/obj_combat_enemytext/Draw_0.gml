draw_self();
draw_set_font(fnt_text_basic);
draw_text_ext(x+8, y+8, displaytext,20,740);