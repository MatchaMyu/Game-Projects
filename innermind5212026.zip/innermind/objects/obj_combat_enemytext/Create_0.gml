fulltext = "I am Error";
face = spr_error_face;
displaytext = "";

textspeed = 0.5;
counter = 0;

delaycounter = 0; // Counter for the delay

caretposition = "null";
textBeforeCaret = "null";
textAfterCaret = "null";

playerturn = 0; //Is it the players turn once this is destroyed?
enemyturn = 0; //Is it the enemy's turn once this is destroyed?

endcombat = 0; //Used for when the enemy ends combat after text.