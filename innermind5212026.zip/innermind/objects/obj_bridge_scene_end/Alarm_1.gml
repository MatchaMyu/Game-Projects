spoken = 0;
maxspoken = 2;
fulltext = "...";
fulltext1 = "\"Oh well, good thing the water isn't deep!\"";

if enabled != 3
{
enabled = 3;
scr_talking(id);
}