instance_destroy(obj_forest_bridge);
enabled = 2;
alarm_set(1,60);