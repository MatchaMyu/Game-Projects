active = 0;
letter = "v"; //This is the letter being used.