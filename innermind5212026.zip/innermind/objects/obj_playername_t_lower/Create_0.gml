active = 0;
letter = "t"; //This is the letter being used.