thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 1;
face = obj_textbox_image_parent;
interact = 0;
fulltext = "*Safe this way\n<----";
talkedwith = 0;
interact = 0;

//Interact changes the fulltext in the key press event.