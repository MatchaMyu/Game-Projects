thespecial = 1; //Triggers special events in the script talking
spoken = 0;
maxspoken = 4;
face = spr_unknown_face;
fulltext = "\"...\"";
fulltext1 = "\"Hey! That was a pretty big fall!\"";
fulltext2 = "\"Are you okie?\"";
fulltext3 = "\"Wait is that a...EEP!\"";

scr_talking(id);