if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{
 scr_talking(id);
}