if global.forestdarknessdone == 1
{
	instance_destroy();
}


spoken = 0;
active = 0;
enabled = 0;

thespecial = 0; //Triggers special events in the script talking
maxspoken = 1;
face = obj_textbox_image_parent;

fulltext = "\"Safe's way is kinda dark, huh?\"";

triggered = 0;