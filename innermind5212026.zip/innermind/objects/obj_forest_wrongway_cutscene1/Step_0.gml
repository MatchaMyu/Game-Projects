if enabled = 0 && active = 0
{
	if (place_meeting(x, y, obj_player))
	{
	 scr_talking(id);
	 enabled = 1;
	 triggered = 1;
	}
}

if triggered = 1 && !instance_exists(obj_textbox_box)
{
	instance_destroy();
}