if place_meeting(x,y,obj_pushable_master)
{
	turnedon = true;
	if instance_exists(obj_forest_gate)
	{
		with obj_forest_gate
		{
			if !place_meeting(x,y,obj_player) && !place_meeting(x,y,obj_pushable_master)
			{
			visible = true;
			solid = true;
			}
		}
	}
}
else
{
	turnedon = false;
	if instance_exists(obj_forest_gate)
	{
		with obj_forest_gate
		{
			visible = false;
			solid = false;
		}
	}
}