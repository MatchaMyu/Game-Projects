active = 0;
letter = "L"; //This is the letter being used.