global.playerx = 960;
global.playery = 400;
room_goto(rm_forest7);