active = 0;
letter = "g"; //This is the letter being used.