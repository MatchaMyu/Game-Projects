global.playerx = 928;
global.playery = 368;
room_goto(rm_forest5);