draw_self();
for (var i = 0; i < ds_list_size(global.inventory); i++) {
        draw_text(x+8,y + 2 + i * 20, ds_list_find_value(global.inventory, i));
    }