global.playerx = 640;
global.playery = 224;
room_goto(rm_forest2);