active = 0;
letter = "e"; //This is the letter being used.