global.playerhp_current = global.playerhp_current - 2;
instance_destroy();