speed = 2.5; // Adjust the speed as needed

// Randomly choose if it starts from the left or right
if obj_combat_blank.turncount = 1
{ 
	x = obj_combat_enemy.x;
    direction = 180;
} else if obj_combat_blank.turncount = 2 {

    x = obj_combat_enemy.x + sprite_width; // Start off-screen to the right
    direction = 90; // Move up
} else { 
	x = obj_combat_enemy.x; //repeat...
	direction = 180;
}

y = irandom_range(64,520);
destroy = 0;
alarm_set(0,30)