with obj_combat_blank
{
	alarm_set(3,1);
}