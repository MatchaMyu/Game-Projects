draw_set_alpha(fade_alpha); // Custom variable you'll control
draw_set_color(c_black);    // Or any color you'd like
draw_rectangle(0, 0, room_width, room_height, false);
draw_set_alpha(1); // Reset alpha after drawing