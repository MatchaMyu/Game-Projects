fade_alpha = 1; // Start fully black
fade_speed = 0.1; // Customize how fast it fades
fading_in = true;
alarm_set(0,10);