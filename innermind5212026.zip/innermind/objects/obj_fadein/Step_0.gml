if (fading_in) {
    fade_alpha -= fade_speed;
    if (fade_alpha <= 0) {
        fade_alpha = 0;
        fading_in = false;
        // Optional: destroy yourself when done
        // instance_destroy();
    }
}

if (!fading_in) {
    fade_alpha += fade_speed;
    if (fade_alpha >= 1) {
        fade_alpha = 1;
        // maybe go to a new room here?
    }
}
