if global.story < 2
{
	global.enemy = 101;
	global.story = 2;
	global.currentroom = room;
	global.playerx = obj_player.x;
	global.playery = obj_player.y;
	if !instance_exists(obj_fight_transition_controller)
	{
		instance_create_depth(x,y,-99,obj_fight_transition_controller);
	}
}
