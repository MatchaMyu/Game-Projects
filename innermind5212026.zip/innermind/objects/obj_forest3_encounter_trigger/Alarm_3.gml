if !instance_exists(obj_textbox_box)
{
global.story = global.story + 1;
active = 0;
instance_destroy();
}