if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{
//TODO: Put this in the script ID.
if instance_exists(obj_textbox_box) && active = 1
	{
		if obj_textbox_box.displaytext = obj_textbox_box.fulltext
		{
			
		with obj_textbox_box 
			{ 
			fulltextdisplay = fulltextdisplay + 1;
			displaytext = "";
			counter = 0;
			alarm_set(0,1); 
			}
			spoken = spoken + 1;
			if spoken >= 3
			{
			instance_destroy(obj_textbox_box);
			instance_destroy();
			}
			switch spoken
			{
			case 0: obj_textbox_box.fulltext = obj_forest3_encounter_trigger.fulltexttemp1; break;
			case 1: obj_textbox_box.fulltext = obj_forest3_encounter_trigger.fulltexttemp2; break;
			case 2: obj_textbox_box.fulltext = obj_forest3_encounter_trigger.fulltexttemp3; global.story = global.story + 1; global.cutscene = 0; with obj_forest_innerchild_encounter2{enable = 1;}; break;
			case 3: instance_destroy();
			}

		}
	}

}