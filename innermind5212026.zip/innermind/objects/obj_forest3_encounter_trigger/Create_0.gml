if global.story > 2
{
instance_destroy();
}

if global.story = 2
{
alarm_set(0,1);
}

global.currentroom = room;

face = spr_cookie_face;
face1 = spr_cookie_face_happy;
face2 = spr_cookie_face;
spoken = 0;
active = 0;

fulltexttemp1 = "Null" + global.enemy_results.cookie;
fulltexttemp2 = "Null22";
fulltexttemp3 = "Null33";

if (global.enemy_results.cookie == "allied")
{
			fulltexttemp1 = "Thanks for the tutorial! What's your name?";
			fulltexttemp2 = global.playername + "? That's a weird name. Cookie's name is Cookie!";
			fulltexttemp3 = "Are you lost? Cookie knows the way! Cookie can help you get out of here!";
}

if (global.enemy_results.cookie == "flee")
{
			fulltexttemp1 = "Huh? Why did you run? You chased Cookie first! You're weird! What is your name?";
			fulltexttemp2 = global.playername + "? That's a weird name. Cookie's name is Cookie!";
			fulltexttemp3 = "Are you lost? Cookie knows the way! Cookie can help you get out of here!";
}