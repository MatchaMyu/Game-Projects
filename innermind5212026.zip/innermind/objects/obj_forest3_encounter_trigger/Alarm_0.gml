active = 1
//Because this is an odd script, it behaves differently from others.
//Could take it and reuse it for "Beginning" areas but need to refine it.

if !instance_exists(obj_textbox_box) && active = 1
{	
	with instance_create_layer(x, y, "Instances_text",obj_textbox_box)
	{
		face = spr_cookie_face;
		face1 = spr_cookie_face_happy;
		face2 = spr_cookie_face;
		switch other.spoken
		{
		case 0: fulltext = obj_forest3_encounter_trigger.fulltexttemp1; break;
		case 1: 
		if (string_lower(global.playername) == "cookie")
		{
        fulltext = "\"Cookie's name is Cookie? That's Cookie's name too!\"";
		}
		else
		{
        fulltext = obj_forest3_encounter_trigger.fulltexttemp2;
		}
		break;
		case 2: fulltext = obj_forest3_encounter_trigger.fulltexttemp3; with obj_forest_innerchild_encounter2{enable = 1;} break;
		default: fulltext = "\"Cookie made an error!\""; global.story = global.story + 1; break;
		}
	}
	global.cutscene = 1;
}
