if instance_destroy(obj_combat_talk_choice1)
{
	instance_destroy(obj_combat_talk_choice1)
}

if instance_destroy(obj_combat_talk_choice2)
{
	instance_destroy(obj_combat_talk_choice2)
}

if instance_destroy(obj_combat_talk_choice3)
{
	instance_destroy(obj_combat_talk_choice3)
}

if instance_destroy(obj_combat_act_choice1)
{
	instance_destroy(obj_combat_act_choice1)
}