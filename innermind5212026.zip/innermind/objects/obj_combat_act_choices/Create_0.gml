talk = 0;
act = 0;
item = 0;
action = 0;
x = 242;
y = 528;
alarm_set(0,1)