if act = 1
{
		with instance_create_depth(x,y,-19,obj_combat_act_choice1) //Attack. NOT based on enemy.
			{
			choice = 1;
			active = 1;
			}
			
		switch global.enemy //MIGHT be based on the enemy...TBD?
		{
		case 101: 
		with instance_create_depth(x,y+32,-19,obj_combat_talk_choice2) 
			{
			choice = 1;
			active = 0;
			}
		break;
		default: break;
		}
}