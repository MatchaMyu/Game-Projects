active = 0;
letter = "h"; //This is the letter being used.