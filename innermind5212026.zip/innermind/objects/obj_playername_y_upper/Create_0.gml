active = 0;
letter = "Y"; //This is the letter being used.