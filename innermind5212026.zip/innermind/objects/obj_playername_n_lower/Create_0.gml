active = 0;
letter = "n"; //This is the letter being used.