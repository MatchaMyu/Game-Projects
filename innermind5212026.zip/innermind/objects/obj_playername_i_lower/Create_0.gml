active = 0;
letter = "i"; //This is the letter being used.