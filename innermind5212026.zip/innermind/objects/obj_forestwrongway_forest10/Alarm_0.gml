global.playerx = 80;
global.playery = 352;
room_goto(rm_forest10);