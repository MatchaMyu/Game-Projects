thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 1;
face = spr_key_face;
fulltext = "It's an imposing door with a huge keyhole. You look inside the keyhole and spot... another smaller keyhole.";

if global.story >= 2
{
instance_destroy();
}