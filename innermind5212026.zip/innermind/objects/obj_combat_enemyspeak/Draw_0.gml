draw_self();
draw_set_font(fnt_text_basic);

// Initialize variables for positioning and color
specialWord = "SAVE";
specialColor = c_yellow;
normalColor = c_white;

var x_pos = x + 220;
var y_pos = y + 8;
var line_height = 30; // Text height. Increase/decrease for spacing
var box_width = 500; // Maximum width for text wrapping. Set to the view with face accounted for
var current_x = x_pos; // Start x position for drawing

var words = string_split(displaytext, " ");

// To manage word wrapping manually, we need to track the current line width
var current_line_width = 0;

for (var i = 0; i < array_length(words); i++) {
    var word = words[i] + " "; // Include space in the word to maintain spacing
    var word_width = string_width(word);

    // Check if adding this word would exceed the box width
    if (current_line_width + word_width > box_width) {
        // Move to the next line
        y_pos += line_height;
        current_x = x_pos;
        current_line_width = 0;
    }

    if (word == specialWord + " ") {
        draw_set_color(specialColor); // Set color for special word
    } else {
        draw_set_color(normalColor); // Set normal color
    }
    
    // Draw the word immediately after setting the color
    draw_text(current_x, y_pos, word);

    // Update the x position for the next word based on the width of the current word
    current_x += word_width;
    current_line_width += word_width; // Update the current line width
}

// Reset the color to default after all words are drawn
draw_set_color(normalColor);
