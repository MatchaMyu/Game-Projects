event_inherited();
scr_battletalking(id); //Calls for the face...etc.