active = 0;
letter = "f"; //This is the letter being used.