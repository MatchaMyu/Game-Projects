active = 0;
letter = "o"; //This is the letter being used.