if movement = 1
{
	if place_free(x,y + 64)
	{
	y = y + 64;
	}
}