if movement = 1
{
	if place_free(x + 64,y)
	{
	x = x + 64;
	}
}