active = 0;
letter = "q"; //This is the letter being used.