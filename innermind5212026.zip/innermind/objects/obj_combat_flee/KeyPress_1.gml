if active = 1
{
	if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
	{
	
	active = 0;
	scr_fleeing();
	
	}
}