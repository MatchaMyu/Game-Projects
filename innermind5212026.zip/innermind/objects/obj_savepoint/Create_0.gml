thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 3;
face = obj_textbox_image_parent;
fulltext = "* You're not sure what this is, but you feel pretty SAVE here.";
fulltext1 = "* Save?";

/*
THIS IS NOT YET FUNCTIONAL!
Overall the goal is to put it in a place a player feels SAFE in, and you get a message about being SAVE
in the general enviroment. As this is nonfunctional, the key press to interact with it is disabled.
*/