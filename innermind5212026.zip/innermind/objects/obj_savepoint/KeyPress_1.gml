/*

if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{
	if distance_to_object(obj_player) < 96
	{
	instance_create_depth(x,y,-599,obj_textbox_save)

}
}

*/