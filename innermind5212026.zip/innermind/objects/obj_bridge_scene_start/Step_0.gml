if enabled = 0 && active = 0
{
	if (place_meeting(x, y, obj_player))
	{
	 scr_talking(id);
	 enabled = 1;
	 global.scene_pause = 1;
	 instance_destroy(obj_bridge_water_scene); //prevents overriding errors.
	}
}