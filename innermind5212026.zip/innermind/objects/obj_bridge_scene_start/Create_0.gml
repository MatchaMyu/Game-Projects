if global.story >= 5
{
	instance_destroy();
}

spoken = 0;
active = 0;
enabled = 0;

thespecial = 1; //Triggers special events in the script talking
maxspoken = 3;
face = obj_textbox_image_parent;

fulltext = "\"Wait! That bridge doesn't look very SAVE !\"";
fulltext1 = "\"You should move super slow!\"";
fulltext2 = "\"Also, dramatic music should play!\"";