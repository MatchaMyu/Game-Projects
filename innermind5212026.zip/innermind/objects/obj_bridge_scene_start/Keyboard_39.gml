if enabled = 1 && obj_bridge_scene_end.enabled = 0
{

with obj_player
{
	if (pause = 0) && (global.pause = false)
{
	if place_free(x + 1,y)
	{
	x = x + 1;
	}
}

}

}