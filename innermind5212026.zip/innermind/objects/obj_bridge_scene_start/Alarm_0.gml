active = 1;
global.story = 5;