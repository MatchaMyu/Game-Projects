ttime --;

if ttime <= 0
{
	global.pause = false;
	room_goto(rm_combat);
}