// Pause all gameplay
global.pause = true;

ttime = 60;
