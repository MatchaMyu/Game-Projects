room_goto(rm_forest3);
