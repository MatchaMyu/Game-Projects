active = 0;
letter = "X"; //This is the letter being used.