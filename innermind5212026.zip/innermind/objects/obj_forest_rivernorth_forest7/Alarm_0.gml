global.playerx = 576;
global.playery = 96;
room_goto(rm_forest7);