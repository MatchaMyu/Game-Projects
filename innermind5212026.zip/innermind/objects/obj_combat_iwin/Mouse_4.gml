//Debug purposes only.
room_goto(global.currentroom);
