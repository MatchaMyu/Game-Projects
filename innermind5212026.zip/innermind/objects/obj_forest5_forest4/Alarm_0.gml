global.playerx = 928;
global.playery = 432;
room_goto(rm_forest4);