global.playerx = 2960;
global.playery = 944;
room_goto(rm_forest8);