if active = 1
{
	if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
	{
		if (string_length(global.playername)) < 9
		{
		global.playername += letter;
		}
	}
}