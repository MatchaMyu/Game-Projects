active = 0;
letter = "a"; //This is the letter being used.
//This is a PARENT of EVERY OTHER LETTER