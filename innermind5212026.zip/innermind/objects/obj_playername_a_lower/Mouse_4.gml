if (string_length(global.playername)) < 9
{
global.playername += letter;
}
active = 1;