draw_set_font(fnt_playername);
if active = 0
{
draw_text_colour(x+6, y-6, letter, c_white,c_white,c_white,c_white, 1);
}
else
{
draw_text_colour(x+6, y-6, letter, c_purple,c_purple,c_purple,c_purple, 1);
exit;
}
