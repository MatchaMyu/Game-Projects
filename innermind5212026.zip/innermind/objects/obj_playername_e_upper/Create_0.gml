active = 0;
letter = "E"; //This is the letter being used.