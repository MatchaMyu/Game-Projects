active = 0;
letter = "S"; //This is the letter being used.