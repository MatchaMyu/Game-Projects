image_speed = 0;
image_index = 0;

talkedwith = 0;

if global.foresttreasure1 = 1
{
talkedwith = 1;
}

thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 3;


face = obj_textbox_image_parent;

fulltext = "* It looks like a crudely drawn treasure chest on the ground.";
fulltext1 = "Oh! Cookie already opened that treasure. Here, Cookie will split it!";
fulltext2 = "Obtained 10 gold!";