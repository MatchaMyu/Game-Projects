if talkedwith > 0
{
fulltext = "* Wait...^3 How did Cookie find gold in this treasure in the first place?";
maxspoken = 1;
fulltext1 = undefined;
}

if (keyboard_check(global.confirm_key1) || keyboard_check(global.confirm_key2))
{

if distance_to_object(obj_player) < 64
{
	global.foresttreasure1 = 1;
	scr_talking(id);
}

}