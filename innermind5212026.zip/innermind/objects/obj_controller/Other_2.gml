//For browsers

if (os_browser != browser_not_a_browser)
{
var scale = min(display_get_width() / 1024, display_get_height() / 768);

window_set_size(1024 * scale, 768 * scale);
}
//This CAN become a step event and it works but it can be blurry and probably slow.