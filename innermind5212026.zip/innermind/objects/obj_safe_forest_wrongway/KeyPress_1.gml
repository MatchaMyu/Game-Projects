if talkedwith > 0
{
	if talkedwith <= 10
	{
		fulltext = "*A note reads: This safe can never be opened. Please don't try - Developer";
	}
	else if talkedwith <= 20
	{
	fulltext = "Seriously. Stop trying to open this.";
	}
	else
	{
	fulltext = "Alright. This message will repeat infinitely now. You can stop trying. Please, go play the rest of the game.";
	}
	maxspoken = 1;
}

if (keyboard_check_pressed(global.confirm_key1) || keyboard_check_pressed(global.confirm_key2))
{

if distance_to_object(obj_player) < 64
{
	if interacted == 0
	{
	global.pause = 1;
	alarm_set(0,30);
	global.forestdarknessdone = 1;
	} 
	else
	{
	scr_talking(id);
	}
	
	if instance_exists(obj_forest_wrongway_darkness)
	{
		instance_destroy(obj_forest_wrongway_darkness);
	}
}

}