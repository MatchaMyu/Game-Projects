global.pause = 0;
scr_talking(id);
interacted = 1;