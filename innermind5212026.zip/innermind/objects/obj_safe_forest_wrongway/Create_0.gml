if global.forestdarknessdone == 1
{
	instance_destroy();
}

thespecial = 0; //Triggers special events in the script talking
spoken = 0;
maxspoken = 1;
face = obj_textbox_image_parent;
talkedwith = 0;
interacted = 0;

fulltext = "*You found the safe this way!";

//Interact changes the fulltext in the key press event.