active = 0;
letter = "s"; //This is the letter being used.